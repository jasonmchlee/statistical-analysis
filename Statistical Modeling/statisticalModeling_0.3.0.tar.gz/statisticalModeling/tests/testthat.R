library(testthat)
library(statisticalModeling)

test_check("statisticalModeling")
